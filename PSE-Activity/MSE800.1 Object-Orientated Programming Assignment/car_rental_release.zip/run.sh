#!/usr/bin/env bash
python main.py
